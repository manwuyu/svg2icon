---
title: 快速使用
order: 1
---


## test

<code src="../src/demos/test.tsx">
