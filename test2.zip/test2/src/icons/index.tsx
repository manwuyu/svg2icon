// GENERATE BY ./scripts/generate.ts
// DON NOT EDIT IT MANUALLY

export { default as TestIcon1 } from './TestIcon1';
