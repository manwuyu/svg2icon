// GENERATE BY ./scripts/generate.ts
// DON NOT EDIT IT MANUALLY

import * as React from 'react';
import Icon from '@ant-design/icons';

import TestIcon1Svg from '../../svg/test/icon1_测试图标.svg';
// 测试图标
const TestIcon1 = (props, ref) => {
    return <Icon component={TestIcon1Svg} {...props} ref={ref} />;
};

export default React.forwardRef(TestIcon1);
