// @ts-nocheck
import React from 'react';
import { dynamic } from 'dumi';
import rawCode1 from '!!dumi-raw-code-loader!D:/workspace/组件代码/test1/src/demos/test.tsx?dumi-raw-code';

export default {
  'test1-test': {
    component: (require('D:/workspace/组件代码/test1/src/demos/test.tsx')).default,
    previewerProps: {"sources":{"_":{"tsx":rawCode1}},"dependencies":{"antd":{"version":"4.22.1","css":"antd/dist/antd.css"},"@manwuyu/icon":{"version":"0.0.1"},"react":{"version":">=16.9.0"},"copy-to-clipboard":{"version":"3.3.1"},"react-dom":{"version":">=16.9.0"}},"identifier":"test1-test"},
  },
};
